package recsys.datapreparer;

import java.io.IOException;
import java.util.List;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;

import recsys.algorithms.cf.CollaborativeFiltering;
import recsys.algorithms.cf.SimilarityMeasure;
import recsys.algorithms.cf.TypeOfNeighborhood;

public class GenerateCsv {
	public static void main(String[] args) {
		long tStart = System.currentTimeMillis();
		DataPreparerCollaborativeFiltering dtp = new DataPreparerCollaborativeFiltering();
		dtp.CreateFileData("data/file.csv");
		long tEnd = System.currentTimeMillis();
		long tDelta = tEnd - tStart;
		System.out.println(tDelta / 1000.0);
		
//		try {
////			CollaborativeFiltering cf = new CollaborativeFiltering();
//			CollaborativeFiltering cf = new CollaborativeFiltering(1);
//			List<RecommendedItem> recs = cf.UserBase(SimilarityMeasure.LOGLIKELIHOOD_SIMILARITY, TypeOfNeighborhood.NEARESTNUSER, 5, 24, 10);
//			for (RecommendedItem recommendedItem : recs) {
//				System.out.println(recommendedItem.getItemID() + ": " + recommendedItem.getValue());
//			}
//		} catch (TasteException | IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
}