package recsys.algorithms.cf;

public enum TypeOfNeighborhood {
	NEARESTNUSER, THRESHOLDSUSER;
}
