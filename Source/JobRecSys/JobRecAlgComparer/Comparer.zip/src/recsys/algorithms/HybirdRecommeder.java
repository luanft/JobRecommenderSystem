package recsys.algorithms;

public class HybirdRecommeder extends  RecommendationAlgorithm{

	public void contentBasedFiltering()
	{
		
	}
	
}
