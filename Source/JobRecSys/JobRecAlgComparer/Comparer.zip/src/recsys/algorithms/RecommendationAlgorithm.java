package recsys.algorithms;

public class RecommendationAlgorithm {

}
