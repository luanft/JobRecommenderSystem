package recsys.algorithms.hybird;

import java.util.ArrayList;

public class UserProfile {

	public String catetory;
	public String CvName;
	public String accountId;
	public String location;
	public String salary;
	public String gender;
	
	public String field;
	public String skill;
	//muc tieu nghe nghiep
	public String target;
	
	public String languages;	
	public String education;	
	
	public ArrayList<String> userRatingList = null;
}
