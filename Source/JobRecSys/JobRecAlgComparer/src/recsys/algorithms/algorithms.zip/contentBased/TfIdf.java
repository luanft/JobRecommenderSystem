package recsys.algorithms.contentBased;

import java.util.HashMap;
import java.util.List;

public class TfIdf {

	/**
	 * Calculates the tf of term termToCheck
	 * 
	 * @param totalterms
	 *            : Array of all the words under processing document
	 * @param termToCheck
	 *            : term of which tf is to be calculated.
	 * @return tf(term frequency) of term termToCheck
	 */
	public double tfCalculator(String[] totalterms, String termToCheck) {
		double count = 0;
		for (String s : totalterms) {
			if (s.equals(termToCheck)) {
				count++;
			}
		}
		return count;
	}

	/**
	 * Calculates idf of term termToCheck
	 * 
	 * @param profileSet
	 *            : all the terms of all the documents
	 * @param termToCheck
	 * @return idf(inverse document frequency) score
	 */
	public double idfCalculator(HashMap<String, String[]> profileSet, HashMap<String, String[]> userSet,
			String termToCheck) {
		double count = 0;
		String[] docTermItem;
		String[] docTermUser;
		for (String key : profileSet.keySet()) {
			docTermItem = profileSet.get(key);
			for (String term : docTermItem) {
				if (term.equals(termToCheck)) {
					count++;
					break;
				}
			}
		}
		for (String key : userSet.keySet()) {
			docTermUser = userSet.get(key);
			for (String term : docTermUser) {
				if (term.equals(termToCheck)) {
					count++;
					break;
				}
			}
		}		
		double val = (profileSet.size() + userSet.size()) / (count + 1);
		return Math.log(1.0d + val);
	}
	
	public double idfCalculator(List<String[]>  documentSet, String termToCheck) {
		double count = 1.0d;		
		for(String[] doc : documentSet)
		{
			for(String term : doc)
			{
				if(term.equals(termToCheck))
				{
					count++;
					break;
				}
			}
		}		
		double val = (documentSet.size()) / count ;
		return Math.log(1.0d + val);
	}
}