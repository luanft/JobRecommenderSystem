package recsys.algorithms.contentBased;

public class ThreadUser extends Thread {
	private MemoryDocumentProcessor mem = null;	
	@Override
	public void run() {		
		mem.tfIdfCalculatorForUser();		
	}
	public MemoryDocumentProcessor getMem() {
		return mem;
	}
	public void setMem(MemoryDocumentProcessor mem) {
		this.mem = mem;
	}
}
