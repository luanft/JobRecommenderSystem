package recsys.algorithms.contentBased;

public class ThreadItem extends Thread {

	private MemoryDocumentProcessor mem = null;	
	@Override
	public void run() {
		mem.tfIdfCalculatorForItem();
	}
	public MemoryDocumentProcessor getMem() {
		return mem;
	}
	public void setMem(MemoryDocumentProcessor mem) {
		this.mem = mem;
	}

}
