package recsys.algorithms.contentBased;

import dto.CvDTO;
import dto.JobDTO;
import dto.ScoreDTO;
import recsys.algorithms.RecommendationAlgorithm;
import recsys.datapreparer.DataSetReader;
import recsys.datapreparer.DataSetType;

public class ContentBasedRecommender extends RecommendationAlgorithm {

	public ContentBasedRecommender() {
		super();
	}

	private DataSetReader dataSetReader = null;

	public void test(String[] item, String[] profile) {
		MemoryDocumentProcessor memDocProcessor = new MemoryDocumentProcessor();
		memDocProcessor.addUserProfile("u0", profile[0]);
		memDocProcessor.addUserProfile("u1", profile[1]);
		memDocProcessor.addItemContent("i0", item[0]);
		memDocProcessor.addItemContent("i1", item[1]);
		System.out.println("Calcualte idf");
		memDocProcessor.idfCalulator();
		System.out.println("Calcualte tf-idf");
		memDocProcessor.tfIdfCalculatorForItem();
		memDocProcessor.tfIdfCalculatorForUser();
		System.out.println("Calcualte cosineSimilarity");
		memDocProcessor.getCosineSimilarity();
	}

	public void run() {
		int max_thread = 2;
		MemoryDocumentProcessor memDocProcessor = new MemoryDocumentProcessor();
		dataSetReader = new DataSetReader(this.inputDirectory);
		dataSetReader.open(DataSetType.Cv);
		CvDTO cvdto = null;
		System.out.println("Build user profile");
		while ((cvdto = dataSetReader.nextCv()) != null) {			
			String itemId = cvdto.getAccountId() + "";
			String content = cvdto.getAddress() + " ";
			content += cvdto.getCategory() + " ";
			// content += cvdto.getCvName() + " ";
			content += cvdto.getEducation() + " ";
			content += cvdto.getObjective() + " ";
			content += cvdto.getSkill() + " ";
			content += cvdto.getLanguage() + " ";
			memDocProcessor.addUserProfile(itemId, content);
		}
		dataSetReader = new DataSetReader(this.inputDirectory);
		dataSetReader.open(DataSetType.Job);

		System.out.println("Build item profile");

		memDocProcessor.createTokenizer();
		JobDTO dto = null;						
		while ((dto = dataSetReader.nextJob()) != null) {									
			String itemId = dto.getJobId() + "";
			System.out.println("Build item profile id " + itemId);
			String content = dto.getJobName() + " ";
			content += dto.getRequirement() + " ";
			content += dto.getLocation() + " ";
			content += dto.getTags() + " ";
			content += dto.getDescription() + " ";
			content += dto.getCategory() + " ";
			memDocProcessor.addItemContent(itemId, content);
		}
		
		
		System.out.println("Calcualte idf");
		memDocProcessor.idfCalulator();
		System.out.println("Calcualte tf-idf");
		memDocProcessor.tfIdfCalculatorForUser();
		memDocProcessor.tfIdfCalculatorForItem();
		

		dataSetReader = new DataSetReader(this.inputDirectory);
		dataSetReader.open(DataSetType.Score);
		ScoreDTO sdto = null;
		while ((sdto = dataSetReader.nextScore()) != null) {
			if (sdto.getScore() == 5 || sdto.getScore() == 4) {
				memDocProcessor.addHistory(sdto.getUserId() + "", sdto.getJobId() + "");
			}
		}
		System.out.println("Calcualte cosineSimilarity");
		memDocProcessor.getCosineSimilarity(this.outputDirectory);
	}

}
