package recsys.algorithms.collaborativeFiltering;

public enum CFAlgorithm {
	UserBase, ItemBase
}
