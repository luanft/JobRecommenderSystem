package recsys.algorithms.collaborativeFiltering;

public enum TypeOfNeighborhood {
	NEARESTNUSER, THRESHOLDSUSER;
}
