package recsys.algorithms.collaborativeFiltering;

public enum SimilarityMeasure {
	PEARSON_CORRELATION, SPEARMAN_CORRELATION, EUCLIDEAN_DISTANCE, TANIMOTO_COOFFICIENT, LOGLIKELIHOOD_SIMILARITY;
}