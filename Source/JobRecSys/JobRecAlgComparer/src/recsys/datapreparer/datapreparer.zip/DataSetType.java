package recsys.datapreparer;

public enum DataSetType {
	Job, Cv, Score
}
